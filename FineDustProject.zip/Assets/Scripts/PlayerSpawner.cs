﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSpawner : MonoBehaviour
{
    public GameObject playerObj;
    //public PlayerStatus player;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void Spawn()
    {
        Vector3 spawnPos;

       

        //spawnPos += Vector3.up * 0.6f;

        //GameObject mon = Instantiate(monObj, spawnPos, Quaternion.identity);
    }
}
