# CHANGELOG

## 1.9.2

- Ensure `_writeString` adds enough padding to null terminate strings.

## 1.9.1

- Changed constant identifiers to be compatible with Dart 2.x
- No longer supports Dart 1.x

## 1.9.0

- Initial release, supports Dart 1.x and many dev versions of Dart 2.x